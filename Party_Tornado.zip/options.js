console.log("Loading options.js...");

const OPTIONS = [
  "🕰️🌎❓Timeguessr🕰️🌎❓",
  "🤡Quiplash🤡",
  "✅Scattergories🚫",
  "➡️⬇️Crossword➡️⬇️",
  "⛳🏌️Golf with Friends⛳🏌️",
  "🧦👨‍⚖️Guilty As Sock🧦👩‍⚖️",
  "✏️🎨Drawful✏️🎨",
  "🤷‍♂️Blather Round🤷‍♂️",
  "⛳🏎️🏁Turbo Golf Racing⛳🏎️🏁",
  "⁉️🔪🩸🎉Trivia Murder Party⁉️🔪🩸🎉",
  "⚔️🛡️Valheim⚔️🛡️",
  "🕵️‍♂️Code Names🕵️‍♀️",
  "✨✨✨Try The New Thing Someone Just Suggested!✨✨✨"
];

console.log("OPTIONS initialized:", OPTIONS);